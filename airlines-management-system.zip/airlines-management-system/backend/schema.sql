-- Airlines Management System - Oracle XE schema
-- Run in SQL*Plus / SQL Developer, in this order.

-- ===== 1. Create tables =====
CREATE TABLE Flights (
    FlightID INT PRIMARY KEY,
    AirlineName VARCHAR(100),
    SourceAirportID INT,
    DestinationAirportID INT,
    DepartureTime TIMESTAMP,
    ArrivalTime TIMESTAMP,
    FlightStatus VARCHAR(50)
);

CREATE TABLE Passengers (
    PassengerID INT PRIMARY KEY,
    Name VARCHAR(100),
    Email VARCHAR(100) UNIQUE,
    PhoneNumber VARCHAR(20),
    PassportNumber VARCHAR(50) UNIQUE
);

CREATE TABLE Reservations (
    ReservationID INT PRIMARY KEY,
    SeatNumber VARCHAR(10),
    PaymentStatus VARCHAR(50),
    BookingDate TIMESTAMP
);

CREATE TABLE Staff (
    StaffID INT PRIMARY KEY,
    Name VARCHAR(100),
    Role VARCHAR(50),
    WorkHours INT
);

CREATE TABLE Airports (
    AirportID INT PRIMARY KEY,
    AirportName VARCHAR(100),
    City VARCHAR(100),
    Country VARCHAR(100),
    Code VARCHAR(10) UNIQUE
);

CREATE TABLE Payments (
    PaymentID INT PRIMARY KEY,
    Amount DECIMAL(10,2),
    PaymentMethod VARCHAR(50),
    PaymentDate TIMESTAMP
);

CREATE TABLE AssignedTo (
    StaffID INT,
    FlightID INT,
    PRIMARY KEY (StaffID, FlightID),
    FOREIGN KEY (StaffID) REFERENCES Staff(StaffID),
    FOREIGN KEY (FlightID) REFERENCES Flights(FlightID)
);

-- ===== 2. Add foreign keys =====
ALTER TABLE Passengers ADD ReservationID INT;
ALTER TABLE Passengers ADD CONSTRAINT fk_reservation
    FOREIGN KEY (ReservationID) REFERENCES Reservations(ReservationID);

ALTER TABLE Reservations ADD FlightID INT;
ALTER TABLE Reservations ADD CONSTRAINT fk_flight
    FOREIGN KEY (FlightID) REFERENCES Flights(FlightID);

ALTER TABLE Staff ADD AirportID INT;
ALTER TABLE Staff ADD CONSTRAINT fk_airport
    FOREIGN KEY (AirportID) REFERENCES Airports(AirportID);

ALTER TABLE Reservations ADD PassengerID INT;
ALTER TABLE Reservations ADD CONSTRAINT fk_passenger
    FOREIGN KEY (PassengerID) REFERENCES Passengers(PassengerID);

ALTER TABLE Payments ADD PassengerID INT;
ALTER TABLE Payments ADD CONSTRAINT fk_passenger_payment
    FOREIGN KEY (PassengerID) REFERENCES Passengers(PassengerID);

ALTER TABLE Flights ADD CONSTRAINT fk_source_airport
    FOREIGN KEY (SourceAirportID) REFERENCES Airports(AirportID);
ALTER TABLE Flights ADD CONSTRAINT fk_destination_airport
    FOREIGN KEY (DestinationAirportID) REFERENCES Airports(AirportID);
