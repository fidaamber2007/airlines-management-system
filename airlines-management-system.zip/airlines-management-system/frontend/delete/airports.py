import tkinter as tk
from tkinter import messagebox
import cx_Oracle


def delete_airport():
    airport_id = entry_id.get().strip()

    conn = None
    cursor = None
    try:
        conn = cx_Oracle.connect("system", "fida17", "localhost:1521/XE")
        cursor = conn.cursor()

        # Delete dependent records from flights and staff
        cursor.execute("DELETE FROM flights WHERE sourceairportid = :1 OR destinationairportid = :1", (airport_id,))
        cursor.execute("DELETE FROM staff WHERE airportid = :1", (airport_id,))

        # Now delete from airports
        cursor.execute("DELETE FROM airports WHERE airportid = :1", (airport_id,))
        conn.commit()
        messagebox.showinfo("Success", "Airport and related data deleted successfully.")

    except cx_Oracle.IntegrityError as e:
        messagebox.showerror("Database Error", f"Integrity Error: {str(e)}")
    except Exception as e:
        messagebox.showerror("Database Error", f"Error: {str(e)}")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


# GUI Setup
root = tk.Tk()
root.title("Delete Airport")

tk.Label(root, text="Airport ID").pack()
entry_id = tk.Entry(root)
entry_id.pack()

tk.Button(root, text="Delete", command=delete_airport).pack()

root.mainloop()
