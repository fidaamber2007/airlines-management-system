import tkinter as tk
from tkinter import messagebox
import cx_Oracle


def delete_flight():
    conn = None
    cursor = None
    try:
        # Oracle DB connection
        conn = cx_Oracle.connect("system", "fida17", "localhost:1521/XE")
        cursor = conn.cursor()

        flight_id = entry_id.get().strip()

        if not flight_id:
            messagebox.showwarning("Input Error", "Please enter a Flight ID.")
            return

        # Check if the record exists
        cursor.execute("SELECT * FROM flights WHERE flightid = :1", (flight_id,))
        result = cursor.fetchone()

        if result is None:
            messagebox.showinfo("Not Found", f"No flight found with ID {flight_id}")
            return

        # Delete the record
        cursor.execute("DELETE FROM flights WHERE flightid = :1", (flight_id,))
        conn.commit()
        messagebox.showinfo("Success", f"Flight ID {flight_id} deleted successfully!")

    except cx_Oracle.IntegrityError as e:
        messagebox.showerror("Integrity Error", f"Related data exists. Error: {str(e)}")
    except Exception as e:
        messagebox.showerror("Error", str(e))
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


# GUI setup
root = tk.Tk()
root.title("Delete Flight")
root.geometry("300x150")

tk.Label(root, text="Enter Flight ID to Delete:").pack(pady=10)
entry_id = tk.Entry(root)
entry_id.pack(pady=5)

tk.Button(root, text="Delete Flight", command=delete_flight).pack(pady=10)

root.mainloop()
