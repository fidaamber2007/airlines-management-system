import tkinter as tk
from tkinter import messagebox
import cx_Oracle


def delete_passenger():
    conn = None
    cursor = None
    try:
        # Oracle DB connection
        conn = cx_Oracle.connect("system", "fida17", "localhost:1521/XE")
        cursor = conn.cursor()

        passenger_id = entry_id.get().strip()

        if not passenger_id:
            messagebox.showwarning("Input Error", "Please enter a Passenger ID.")
            return

        # Check if the record exists
        cursor.execute("SELECT * FROM passengers WHERE passengerid = :1", (passenger_id,))
        result = cursor.fetchone()

        if result is None:
            messagebox.showinfo("Not Found", f"No passenger found with ID {passenger_id}")
            return

        # Delete the record
        cursor.execute("DELETE FROM passengers WHERE passengerid = :1", (passenger_id,))
        conn.commit()
        messagebox.showinfo("Success", f"Passenger ID {passenger_id} deleted successfully!")

    except cx_Oracle.IntegrityError as e:
        messagebox.showerror("Integrity Error", f"Related data exists. Error: {str(e)}")
    except Exception as e:
        messagebox.showerror("Error", str(e))
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


# GUI setup
root = tk.Tk()
root.title("Delete Passenger")
root.geometry("300x150")

tk.Label(root, text="Enter Passenger ID to Delete:").pack(pady=10)
entry_id = tk.Entry(root)
entry_id.pack(pady=5)

tk.Button(root, text="Delete Passenger", command=delete_passenger).pack(pady=10)

root.mainloop()
