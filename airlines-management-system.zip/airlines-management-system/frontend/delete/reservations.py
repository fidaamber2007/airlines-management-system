import tkinter as tk
from tkinter import messagebox
import cx_Oracle


def delete_reservation():
    conn = None
    cursor = None
    try:
        # Oracle DB connection
        conn = cx_Oracle.connect("system", "fida17", "localhost:1521/XE")
        cursor = conn.cursor()

        reservation_id = entry_id.get().strip()

        if not reservation_id:
            messagebox.showwarning("Input Error", "Please enter a Reservation ID.")
            return

        # Check if the record exists
        cursor.execute("SELECT * FROM reservations WHERE reservationid = :1", (reservation_id,))
        result = cursor.fetchone()

        if result is None:
            messagebox.showinfo("Not Found", f"No reservation found with ID {reservation_id}")
            return

        # Delete the record
        cursor.execute("DELETE FROM reservations WHERE reservationid = :1", (reservation_id,))
        conn.commit()
        messagebox.showinfo("Success", f"Reservation ID {reservation_id} deleted successfully!")

    except cx_Oracle.IntegrityError as e:
        messagebox.showerror("Integrity Error", f"Related data exists. Error: {str(e)}")
    except Exception as e:
        messagebox.showerror("Error", str(e))
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


# GUI setup
root = tk.Tk()
root.title("Delete Reservation")
root.geometry("300x150")

tk.Label(root, text="Enter Reservation ID to Delete:").pack(pady=10)
entry_id = tk.Entry(root)
entry_id.pack(pady=5)

tk.Button(root, text="Delete Reservation", command=delete_reservation).pack(pady=10)

root.mainloop()
