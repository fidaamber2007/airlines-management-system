import tkinter as tk
from tkinter import messagebox
import cx_Oracle


def delete_staff():
    conn = None
    cursor = None
    try:
        # Oracle DB connection
        conn = cx_Oracle.connect("system", "fida17", "localhost:1521/XE")
        cursor = conn.cursor()

        staff_id = entry_id.get().strip()

        if not staff_id:
            messagebox.showwarning("Input Error", "Please enter a Staff ID.")
            return

        # Check if the record exists
        cursor.execute("SELECT * FROM staff WHERE staffid = :1", (staff_id,))
        result = cursor.fetchone()

        if result is None:
            messagebox.showinfo("Not Found", f"No staff member found with ID {staff_id}")
            return

        # Delete the record
        cursor.execute("DELETE FROM staff WHERE staffid = :1", (staff_id,))
        conn.commit()
        messagebox.showinfo("Success", f"Staff ID {staff_id} deleted successfully!")

    except cx_Oracle.IntegrityError as e:
        messagebox.showerror("Integrity Error", f"Related data exists. Error: {str(e)}")
    except Exception as e:
        messagebox.showerror("Error", str(e))
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


# GUI setup
root = tk.Tk()
root.title("Delete Staff")
root.geometry("300x150")

tk.Label(root, text="Enter Staff ID to Delete:").pack(pady=10)
entry_id = tk.Entry(root)
entry_id.pack(pady=5)

tk.Button(root, text="Delete Staff", command=delete_staff).pack(pady=10)

root.mainloop()
