import tkinter as tk
from tkinter import messagebox
import cx_Oracle


# Oracle DB connection
def connect_to_db():
    try:
        conn = cx_Oracle.connect("system", "fida17", "localhost:1521/XE")
        return conn
    except cx_Oracle.DatabaseError as e:
        messagebox.showerror("Connection Error", "Error connecting to Oracle Database: " + str(e))
        return None


conn = connect_to_db()
if conn is None:
    exit()  # Exit if no database connection is made.

cursor = conn.cursor()


def update_assignedto():
    staffid = entry_staffid.get()
    flightid = entry_flightid.get()

    try:
        query = "UPDATE assignedto SET flightid = :1 WHERE staffid = :2"
        cursor.execute(query, (flightid, staffid))
        conn.commit()
        messagebox.showinfo("Success", "assignedto table updated successfully!")
    except Exception as e:
        messagebox.showerror("Error", str(e))


# GUI
root = tk.Tk()
root.title("Update assignedto")

tk.Label(root, text="Staff ID").grid(row=0, column=0)
entry_staffid = tk.Entry(root)
entry_staffid.grid(row=0, column=1)

tk.Label(root, text="New Flight ID").grid(row=1, column=0)
entry_flightid = tk.Entry(root)
entry_flightid.grid(row=1, column=1)

tk.Button(root, text="Update", command=update_assignedto).grid(row=2, columnspan=2)

root.mainloop()
