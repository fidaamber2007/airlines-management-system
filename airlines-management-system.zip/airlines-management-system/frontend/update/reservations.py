import tkinter as tk
from tkinter import messagebox
import cx_Oracle
from datetime import datetime

# Oracle Database Credentials
username = 'system'
password = 'fida17'
dsn = 'XE'  # Replace with your Oracle service name


def update_reservation():
    conn = None
    cursor = None
    try:
        conn = cx_Oracle.connect(username, password, dsn)
        cursor = conn.cursor()

        # Get values from input fields
        reservationid = entry_fields[0].get()
        passengerid = entry_fields[1].get()
        flightid = entry_fields[2].get()
        seatnumber = entry_fields[3].get()
        paymentstatus = entry_fields[4].get()
        bookingdate_str = entry_fields[5].get()

        # Convert booking date to Oracle date format
        bookingdate = datetime.strptime(bookingdate_str, "%Y-%m-%d")

        # SQL Update Query
        update_query = """
            UPDATE reservations
            SET passengerid = :1,
                flightid = :2,
                seatnumber = :3,
                paymentstatus = :4,
                bookingdate = :5
            WHERE reservationid = :6
        """
        cursor.execute(update_query, (passengerid, flightid, seatnumber, paymentstatus,
                                      bookingdate, reservationid))
        conn.commit()
        messagebox.showinfo("Success", "Reservation updated successfully!")
    except cx_Oracle.DatabaseError as e:
        messagebox.showerror("Database Error", str(e))
    except ValueError:
        messagebox.showerror("Format Error", "Please use YYYY-MM-DD format for the booking date.")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


# Tkinter GUI Setup
root = tk.Tk()
root.title("Update Reservation")

labels = [
    "Reservation ID", "Passenger ID", "Flight ID",
    "Seat Number", "Payment Status", "Booking Date (YYYY-MM-DD)"
]
entry_fields = []

for i, label in enumerate(labels):
    tk.Label(root, text=label).grid(row=i, column=0, padx=10, pady=5, sticky="w")
    entry = tk.Entry(root, width=35)
    entry.grid(row=i, column=1, padx=10, pady=5)
    entry_fields.append(entry)

update_btn = tk.Button(root, text="Update Reservation", command=update_reservation)
update_btn.grid(row=len(labels), column=0, columnspan=2, pady=15)

root.mainloop()
