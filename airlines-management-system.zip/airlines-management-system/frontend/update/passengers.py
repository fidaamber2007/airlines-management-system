import tkinter as tk
from tkinter import messagebox
import cx_Oracle

# Oracle DB credentials
username = 'system'
password = 'fida17'
dsn = 'XE'  # Replace with your actual Oracle service name


def update_passenger():
    conn = None
    cursor = None
    try:
        conn = cx_Oracle.connect(username, password, dsn)
        cursor = conn.cursor()

        passengerid = entry_passengerid.get()
        name = entry_name.get()
        email = entry_email.get()
        phone = entry_phone.get()
        passport = entry_passport.get()

        update_query = """
            UPDATE passengers
            SET name = :1,
                email = :2,
                phonenumber = :3,
                passportnumber = :4
            WHERE passengerid = :5
        """
        cursor.execute(update_query, (name, email, phone, passport, passengerid))
        conn.commit()
        messagebox.showinfo("Success", "Passenger record updated successfully!")
    except cx_Oracle.DatabaseError as e:
        messagebox.showerror("Error", str(e))
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


# GUI Setup
root = tk.Tk()
root.title("Update Passenger Info")

labels = ["Passenger ID", "Name", "Email", "Phone Number", "Passport Number"]
entries = []

for i, label in enumerate(labels):
    tk.Label(root, text=label).grid(row=i, column=0, padx=10, pady=5, sticky="w")
    entry = tk.Entry(root, width=35)
    entry.grid(row=i, column=1, padx=10, pady=5)
    entries.append(entry)

entry_passengerid, entry_name, entry_email, entry_phone, entry_passport = entries

update_btn = tk.Button(root, text="Update Passenger", command=update_passenger)
update_btn.grid(row=len(labels), column=0, columnspan=2, pady=15)

root.mainloop()
