import tkinter as tk
from tkinter import messagebox
import cx_Oracle

# Oracle DB connection
conn = cx_Oracle.connect("system", "fida17", "localhost:1521/XE")
cursor = conn.cursor()


def update_payment():
    paymentid = entry_paymentid.get()
    amount = entry_amount.get()
    method = entry_method.get()
    date = entry_date.get()
    passengerid = entry_passengerid.get()

    try:
        query = """
        UPDATE payments
        SET amount = :1, paymentmethod = :2,
            paymentdate = TO_TIMESTAMP(:3, 'YYYY-MM-DD HH24:MI:SS'),
            passengerid = :4
        WHERE paymentid = :5
        """
        cursor.execute(query, (amount, method, date, passengerid, paymentid))
        conn.commit()
        messagebox.showinfo("Success", "Payment record updated successfully!")
    except Exception as e:
        messagebox.showerror("Error", str(e))


# GUI
root = tk.Tk()
root.title("Update Payment")

tk.Label(root, text="Payment ID").grid(row=0, column=0)
entry_paymentid = tk.Entry(root)
entry_paymentid.grid(row=0, column=1)

tk.Label(root, text="New Amount").grid(row=1, column=0)
entry_amount = tk.Entry(root)
entry_amount.grid(row=1, column=1)

tk.Label(root, text="New Payment Method").grid(row=2, column=0)
entry_method = tk.Entry(root)
entry_method.grid(row=2, column=1)

tk.Label(root, text="New Payment Date (YYYY-MM-DD HH:MM:SS)").grid(row=3, column=0)
entry_date = tk.Entry(root)
entry_date.grid(row=3, column=1)

tk.Label(root, text="New Passenger ID").grid(row=4, column=0)
entry_passengerid = tk.Entry(root)
entry_passengerid.grid(row=4, column=1)

tk.Button(root, text="Update", command=update_payment).grid(row=5, columnspan=2)

root.mainloop()
