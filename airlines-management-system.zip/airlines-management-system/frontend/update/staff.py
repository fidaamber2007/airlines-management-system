import tkinter as tk
import cx_Oracle


# Function to update staff record
def update_staff():
    staffid = entries[0].get()
    name = entries[1].get()
    role = entries[2].get()
    workhours = entries[3].get()
    airportid = entries[4].get()

    conn = None
    try:
        conn = cx_Oracle.connect("system", "fida17", "XE")
        cur = conn.cursor()

        query = """
        UPDATE staff
        SET name = :1, role = :2, workhours = :3, airportid = :4
        WHERE staffid = :5
        """
        cur.execute(query, (name, role, workhours, airportid, staffid))
        conn.commit()
        status_label.config(text="Staff record updated successfully!", fg="green")
    except Exception as e:
        status_label.config(text=f"Error: {str(e)}", fg="red")
    finally:
        if conn:
            conn.close()


# GUI Setup
root = tk.Tk()
root.title("Update Staff Record")

labels = ["Staff ID", "Name", "Role", "Work Hours", "Airport ID"]
entries = []

for i, label in enumerate(labels):
    tk.Label(root, text=label).grid(row=i, column=0, padx=10, pady=5, sticky="w")
    entry = tk.Entry(root, width=30)
    entry.grid(row=i, column=1, padx=10, pady=5)
    entries.append(entry)

update_button = tk.Button(root, text="Update Staff", command=update_staff, bg="lightblue")
update_button.grid(row=len(labels), column=0, columnspan=2, pady=10)

status_label = tk.Label(root, text="", fg="green")
status_label.grid(row=len(labels) + 1, column=0, columnspan=2)

root.mainloop()
