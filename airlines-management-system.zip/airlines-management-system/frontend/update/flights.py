import tkinter as tk
from tkinter import messagebox
import cx_Oracle
from datetime import datetime

# Oracle DB Credentials
username = 'system'
password = 'fida17'
dsn = 'XE'  # Replace with your actual Oracle service name


def update_flight():
    conn = None
    cursor = None
    try:
        conn = cx_Oracle.connect(username, password, dsn)
        cursor = conn.cursor()

        flightid = entry_flightid.get()
        airlinename = entry_airlinename.get()
        source_id = entry_source.get()
        destination_id = entry_destination.get()
        departure_time = entry_departure.get()
        arrival_time = entry_arrival.get()
        flight_status = entry_status.get()

        # Convert to date format expected by Oracle
        departure_dt = datetime.strptime(departure_time, "%Y-%m-%d %H:%M:%S")
        arrival_dt = datetime.strptime(arrival_time, "%Y-%m-%d %H:%M:%S")

        update_query = """
            UPDATE flights
            SET airlinename = :1,
                sourceairportid = :2,
                destinationairportid = :3,
                departuretime = :4,
                arrivaltime = :5,
                flightstatus = :6
            WHERE flightid = :7
        """
        cursor.execute(update_query, (airlinename, source_id, destination_id,
                                      departure_dt, arrival_dt, flight_status, flightid))
        conn.commit()
        messagebox.showinfo("Success", "Flight record updated successfully!")
    except cx_Oracle.DatabaseError as e:
        messagebox.showerror("Error", str(e))
    except ValueError:
        messagebox.showerror("Format Error", "Please enter date/time in correct format: YYYY-MM-DD HH:MM:SS")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


# GUI Setup
root = tk.Tk()
root.title("Update Flight Info")

labels = [
    "Flight ID", "Airline Name", "Source Airport ID",
    "Destination Airport ID", "Departure Time (YYYY-MM-DD HH:MM:SS)",
    "Arrival Time (YYYY-MM-DD HH:MM:SS)", "Flight Status"
]
entries = []

for i, label in enumerate(labels):
    tk.Label(root, text=label).grid(row=i, column=0, padx=10, pady=5, sticky="w")
    entry = tk.Entry(root, width=35)
    entry.grid(row=i, column=1, padx=10, pady=5)
    entries.append(entry)

entry_flightid, entry_airlinename, entry_source, entry_destination, entry_departure, entry_arrival, entry_status = entries

update_btn = tk.Button(root, text="Update Flight", command=update_flight)
update_btn.grid(row=len(labels), column=0, columnspan=2, pady=15)

root.mainloop()
