import tkinter as tk
from tkinter import messagebox
import cx_Oracle

# Oracle credentials
username = 'system'
password = 'fida17'
dsn = 'XE'  # Oracle service name


def update_airport():
    conn = None
    cursor = None
    try:
        conn = cx_Oracle.connect(username, password, dsn)
        cursor = conn.cursor()

        airportid = entry_airportid.get()
        airportname = entry_airportname.get()
        city = entry_city.get()
        country = entry_country.get()
        code = entry_code.get()

        update_query = """
            UPDATE airports
            SET airportname = :1,
                city = :2,
                country = :3,
                code = :4
            WHERE airportid = :5
        """
        cursor.execute(update_query, (airportname, city, country, code, airportid))
        conn.commit()
        messagebox.showinfo("Success", "Airport record updated successfully!")
    except cx_Oracle.DatabaseError as e:
        messagebox.showerror("Error", str(e))
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


# GUI Setup
root = tk.Tk()
root.title("Update Airport Info")

labels = ["Airport ID", "Airport Name", "City", "Country", "Code"]
entries = []

for i, label in enumerate(labels):
    tk.Label(root, text=label).grid(row=i, column=0, padx=10, pady=5, sticky="w")
    entry = tk.Entry(root, width=30)
    entry.grid(row=i, column=1, padx=10, pady=5)
    entries.append(entry)

entry_airportid, entry_airportname, entry_city, entry_country, entry_code = entries

update_btn = tk.Button(root, text="Update Airport", command=update_airport)
update_btn.grid(row=len(labels), column=0, columnspan=2, pady=15)

root.mainloop()
