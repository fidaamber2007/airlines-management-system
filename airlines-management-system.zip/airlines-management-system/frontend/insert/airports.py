import tkinter as tk
from tkinter import messagebox
import cx_Oracle

# === Oracle Database Configuration ===
dsn = cx_Oracle.makedsn("localhost", 1521, service_name="XE")  # change if needed
conn = cx_Oracle.connect(user="system", password="fida17", dsn=dsn)
cursor = conn.cursor()


# === Submit Function ===
def submit_data():
    try:
        airport_id = int(entry_id.get())
        name = entry_name.get()
        city = entry_city.get()
        country = entry_country.get()
        code = entry_code.get()

        query = """INSERT INTO airports (AIRPORTID, AIRPORTNAME, CITY, COUNTRY, CODE)
                   VALUES (:1, :2, :3, :4, :5)"""
        cursor.execute(query, (airport_id, name, city, country, code))
        conn.commit()
        messagebox.showinfo("Success", "Airport inserted successfully!")
        clear_fields()
    except cx_Oracle.DatabaseError as e:
        messagebox.showerror("Database Error", f"Database error: {str(e)}")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {str(e)}")


# === Clear fields ===
def clear_fields():
    entry_id.delete(0, tk.END)
    entry_name.delete(0, tk.END)
    entry_city.delete(0, tk.END)
    entry_country.delete(0, tk.END)
    entry_code.delete(0, tk.END)


# === Close Database Connection on Window Close ===
def close_connection():
    cursor.close()
    conn.close()
    root.destroy()


# === GUI ===
root = tk.Tk()
root.title("Insert Airport")
root.protocol("WM_DELETE_WINDOW", close_connection)

tk.Label(root, text="Airport ID").grid(row=0, column=0)
entry_id = tk.Entry(root)
entry_id.grid(row=0, column=1)

tk.Label(root, text="Airport Name").grid(row=1, column=0)
entry_name = tk.Entry(root)
entry_name.grid(row=1, column=1)

tk.Label(root, text="City").grid(row=2, column=0)
entry_city = tk.Entry(root)
entry_city.grid(row=2, column=1)

tk.Label(root, text="Country").grid(row=3, column=0)
entry_country = tk.Entry(root)
entry_country.grid(row=3, column=1)

tk.Label(root, text="Code").grid(row=4, column=0)
entry_code = tk.Entry(root)
entry_code.grid(row=4, column=1)

tk.Button(root, text="Submit", command=submit_data).grid(row=5, column=0, columnspan=2, pady=10)

root.mainloop()
