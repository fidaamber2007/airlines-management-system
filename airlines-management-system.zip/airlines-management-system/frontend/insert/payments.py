import cx_Oracle
from tkinter import *
from tkinter import messagebox
from datetime import datetime


def insert_payment():
    conn = None
    cursor = None
    try:
        payment_id = int(entry_payment_id.get())
        amount = float(entry_amount.get())
        method = entry_method.get()
        payment_date = entry_date.get()
        passenger_id = int(entry_passenger_id.get())

        # Convert date string to Oracle-compatible format
        oracle_date = datetime.strptime(payment_date, "%Y-%m-%d %H:%M:%S")

        dsn = cx_Oracle.makedsn("localhost", 1521, service_name="XE")  # Adjust as needed
        conn = cx_Oracle.connect(user="system", password="fida17", dsn=dsn)
        cursor = conn.cursor()

        query = """
            INSERT INTO payments (paymentid, amount, paymentmethod, paymentdate, passengerid)
            VALUES (:1, :2, :3, :4, :5)
        """
        cursor.execute(query, (payment_id, amount, method, oracle_date, passenger_id))
        conn.commit()

        messagebox.showinfo("Success", "Payment inserted successfully!")
    except Exception as e:
        messagebox.showerror("Error", str(e))
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


# GUI setup
root = Tk()
root.title("Insert Payment")

Label(root, text="Payment ID").grid(row=0, column=0, padx=10, pady=5)
Label(root, text="Amount").grid(row=1, column=0, padx=10, pady=5)
Label(root, text="Payment Method").grid(row=2, column=0, padx=10, pady=5)
Label(root, text="Payment Date (YYYY-MM-DD HH:MM:SS)").grid(row=3, column=0, padx=10, pady=5)
Label(root, text="Passenger ID").grid(row=4, column=0, padx=10, pady=5)

entry_payment_id = Entry(root)
entry_amount = Entry(root)
entry_method = Entry(root)
entry_date = Entry(root)
entry_passenger_id = Entry(root)

entry_payment_id.grid(row=0, column=1, padx=10, pady=5)
entry_amount.grid(row=1, column=1, padx=10, pady=5)
entry_method.grid(row=2, column=1, padx=10, pady=5)
entry_date.grid(row=3, column=1, padx=10, pady=5)
entry_passenger_id.grid(row=4, column=1, padx=10, pady=5)

Button(root, text="Insert Payment", command=insert_payment).grid(row=5, column=0, columnspan=2, pady=10)

root.mainloop()
