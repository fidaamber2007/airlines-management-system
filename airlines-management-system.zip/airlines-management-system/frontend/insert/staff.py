import tkinter as tk
from tkinter import messagebox
import cx_Oracle

# === Oracle Database Configuration ===
dsn = cx_Oracle.makedsn("localhost", 1521, service_name="XE")  # Update if needed
conn = cx_Oracle.connect(user="system", password="fida17", dsn=dsn)
cursor = conn.cursor()


# === Submit Function ===
def submit_data():
    try:
        staff_id = int(entry_staffid.get())
        name = entry_name.get()
        role = entry_role.get()
        workhours = int(entry_workhours.get())
        airport_id = int(entry_airportid.get())

        query = """INSERT INTO staff (STAFFID, NAME, ROLE, WORKHOURS, AIRPORTID)
                   VALUES (:1, :2, :3, :4, :5)"""
        cursor.execute(query, (staff_id, name, role, workhours, airport_id))
        conn.commit()
        messagebox.showinfo("Success", "Staff member inserted successfully!")
        clear_fields()
    except Exception as e:
        messagebox.showerror("Error", str(e))


# === Clear Entry Fields ===
def clear_fields():
    entry_staffid.delete(0, tk.END)
    entry_name.delete(0, tk.END)
    entry_role.delete(0, tk.END)
    entry_workhours.delete(0, tk.END)
    entry_airportid.delete(0, tk.END)


# === GUI ===
root = tk.Tk()
root.title("Insert Staff Record")

tk.Label(root, text="Staff ID").grid(row=0, column=0)
entry_staffid = tk.Entry(root)
entry_staffid.grid(row=0, column=1)

tk.Label(root, text="Name").grid(row=1, column=0)
entry_name = tk.Entry(root)
entry_name.grid(row=1, column=1)

tk.Label(root, text="Role").grid(row=2, column=0)
entry_role = tk.Entry(root)
entry_role.grid(row=2, column=1)

tk.Label(root, text="Work Hours").grid(row=3, column=0)
entry_workhours = tk.Entry(root)
entry_workhours.grid(row=3, column=1)

tk.Label(root, text="Airport ID").grid(row=4, column=0)
entry_airportid = tk.Entry(root)
entry_airportid.grid(row=4, column=1)

tk.Button(root, text="Submit", command=submit_data).grid(row=5, column=0, columnspan=2, pady=10)

root.mainloop()

# === Cleanup ===
cursor.close()
conn.close()
