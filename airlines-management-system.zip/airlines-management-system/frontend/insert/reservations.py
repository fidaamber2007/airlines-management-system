import tkinter as tk
from tkinter import messagebox
import cx_Oracle
import datetime

# Set up the Oracle DSN (Data Source Name)
dsn = cx_Oracle.makedsn("localhost", 1521, service_name="XE")

# Connect using SYSTEM user (since the tables are under SYSTEM)
connection = cx_Oracle.connect(user="system", password="fida17", dsn=dsn)
cursor = connection.cursor()


# Insert Function
def insert_reservation():
    try:
        # Get values from GUI
        reservation_id = int(entry_reservation_id.get())
        passenger_id = int(entry_passenger_id.get())
        flight_id = int(entry_flight_id.get())
        seat_number = entry_seat_number.get()
        payment_status = entry_payment_status.get()
        booking_date = entry_booking_date.get()

        # Convert booking date string to datetime object
        booking_date_obj = datetime.datetime.strptime(booking_date, "%Y-%m-%d").date()

        # SQL Insert Query
        query = """
            INSERT INTO RESERVATIONS
            (RESERVATIONID, PASSENGERID, FLIGHTID, SEATNUMBER, PAYMENTSTATUS, BOOKINGDATE)
            VALUES (:1, :2, :3, :4, :5, :6)
        """
        cursor.execute(query, (reservation_id, passenger_id, flight_id, seat_number,
                               payment_status, booking_date_obj))
        connection.commit()
        messagebox.showinfo("Success", "Reservation inserted successfully!")
    except Exception as e:
        messagebox.showerror("Error", str(e))


# -------------------- GUI Code --------------------
root = tk.Tk()
root.title("Insert Reservation")

tk.Label(root, text="Reservation ID").pack()
entry_reservation_id = tk.Entry(root)
entry_reservation_id.pack()

tk.Label(root, text="Passenger ID").pack()
entry_passenger_id = tk.Entry(root)
entry_passenger_id.pack()

tk.Label(root, text="Flight ID").pack()
entry_flight_id = tk.Entry(root)
entry_flight_id.pack()

tk.Label(root, text="Seat Number").pack()
entry_seat_number = tk.Entry(root)
entry_seat_number.pack()

tk.Label(root, text="Payment Status").pack()
entry_payment_status = tk.Entry(root)
entry_payment_status.pack()

tk.Label(root, text="Booking Date (YYYY-MM-DD)").pack()
entry_booking_date = tk.Entry(root)
entry_booking_date.pack()

tk.Button(root, text="Insert", command=insert_reservation).pack()

root.mainloop()
