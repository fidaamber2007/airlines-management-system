import cx_Oracle
from tkinter import *
from tkinter import messagebox


def insert_data():
    staff_id = entry_staff_id.get()
    flight_id = entry_flight_id.get()

    conn = None
    cursor = None
    try:
        dsn = cx_Oracle.makedsn("localhost", 1521, service_name="XE")  # Replace with your actual service name
        conn = cx_Oracle.connect(user="system", password="fida17", dsn=dsn)
        cursor = conn.cursor()

        query = """
        INSERT INTO assignedto (staffid, flightid)
        VALUES (:1, :2)
        """
        cursor.execute(query, (staff_id, flight_id))
        conn.commit()

        messagebox.showinfo("Success", "Assignment inserted successfully!")
    except Exception as e:
        messagebox.showerror("Error", str(e))
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


# GUI setup
root = Tk()
root.title("Assign Staff to Flight")

Label(root, text="Staff ID").grid(row=0, column=0, padx=10, pady=5)
Label(root, text="Flight ID").grid(row=1, column=0, padx=10, pady=5)

entry_staff_id = Entry(root)
entry_flight_id = Entry(root)

entry_staff_id.grid(row=0, column=1, padx=10, pady=5)
entry_flight_id.grid(row=1, column=1, padx=10, pady=5)

Button(root, text="Insert", command=insert_data).grid(row=2, column=0, columnspan=2, pady=10)

root.mainloop()
