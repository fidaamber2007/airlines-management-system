import tkinter as tk
from tkinter import messagebox
import cx_Oracle

# Oracle DB connection setup
dsn = cx_Oracle.makedsn("localhost", 1521, service_name="XE")  # Adjust service name if needed
conn = cx_Oracle.connect(user="system", password="fida17", dsn=dsn)
cursor = conn.cursor()


# Insert function
def insert_passenger():
    try:
        passenger_id = int(entry_passenger_id.get())
        name = entry_name.get()
        email = entry_email.get()
        phone = entry_phone.get()
        passport = entry_passport.get()

        query = """
            INSERT INTO passengers (passengerid, name, email, phonenumber, passportnumber)
            VALUES (:1, :2, :3, :4, :5)
        """
        cursor.execute(query, (passenger_id, name, email, phone, passport))
        conn.commit()
        messagebox.showinfo("Success", "Passenger inserted successfully!")
    except Exception as e:
        messagebox.showerror("Error", str(e))


# GUI setup
root = tk.Tk()
root.title("Passenger Entry Form")

tk.Label(root, text="Passenger ID").grid(row=0, column=0)
entry_passenger_id = tk.Entry(root)
entry_passenger_id.grid(row=0, column=1)

tk.Label(root, text="Name").grid(row=1, column=0)
entry_name = tk.Entry(root)
entry_name.grid(row=1, column=1)

tk.Label(root, text="Email").grid(row=2, column=0)
entry_email = tk.Entry(root)
entry_email.grid(row=2, column=1)

tk.Label(root, text="Phone Number").grid(row=3, column=0)
entry_phone = tk.Entry(root)
entry_phone.grid(row=3, column=1)

tk.Label(root, text="Passport Number").grid(row=4, column=0)
entry_passport = tk.Entry(root)
entry_passport.grid(row=4, column=1)

tk.Button(root, text="Insert", command=insert_passenger).grid(row=5, column=0, columnspan=2)

root.mainloop()

# Close connection when window closes
cursor.close()
conn.close()
