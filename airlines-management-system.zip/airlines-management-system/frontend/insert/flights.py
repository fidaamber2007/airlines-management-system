import tkinter as tk
import cx_Oracle


def insert_flight():
    con = None
    cur = None
    try:
        con = cx_Oracle.connect("system", "fida17", "localhost/XE")
        cur = con.cursor()
        cur.execute("""
            INSERT INTO flights VALUES (:1, :2, :3, :4, TO_DATE(:5, 'YYYY-MM-DD'), TO_DATE(:6, 'YYYY-MM-DD'), :7)
        """, (
            int(entry_id.get()), entry_airline.get(), int(entry_src.get()), int(entry_dest.get()),
            entry_dep.get(), entry_arr.get(), entry_status.get()
        ))
        con.commit()
        print("Flight inserted.")
    except Exception as e:
        print("Error:", e)
    finally:
        if cur:
            cur.close()
        if con:
            con.close()


root = tk.Tk()
root.title("Insert Flight")

labels = ["Flight ID", "Airline", "Source Airport ID", "Destination Airport ID",
          "Departure Date (YYYY-MM-DD)", "Arrival Date (YYYY-MM-DD)", "Flight Status"]

entries = []

for i, label in enumerate(labels):
    tk.Label(root, text=label).grid(row=i, column=0)
    entry = tk.Entry(root)
    entry.grid(row=i, column=1)
    entries.append(entry)

entry_id, entry_airline, entry_src, entry_dest, entry_dep, entry_arr, entry_status = entries

tk.Button(root, text="Insert Flight", command=insert_flight).grid(row=len(labels), columnspan=2, pady=10)

root.mainloop()
